/**
 * Created by samir on 4/18/2016.
 */
var usersApp = angular.module('usersAndGroupsApp', ['ui.bootstrap', 'ngTagsInput', 'yaru22.angular-timeago', 'chart.js', 'ui-notification', 'NgSwitchery', 'daterangepicker', 'moment-picker']);