/**
 * Created by afnan on 5/29/2016.
 */

$("#wrapper").on("click", ".btn-secondary", function () {
    $('.profile-info').removeClass('editable');
    $('.user-widget').removeClass('editable');
});