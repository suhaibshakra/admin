/**
 * Created by samir on 4/18/2016.
 */
var dashboardApp = angular.module('dashboardApp', ['yaru22.angular-timeago', 'chart.js', 'ui-notification', 'daterangepicker']);